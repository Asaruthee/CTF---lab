<h1>Welcome Hacker!</h1>
<p>Can you find the secret flag hidden somewhere in the system?</p>
