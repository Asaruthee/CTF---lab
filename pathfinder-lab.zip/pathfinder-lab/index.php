<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// --------------------- FLAG SUBMIT ---------------------
$correct_flag = "CTF{D1rect0ry_Restr1cti0ns_M4tt3r}";
$result = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['flag'])) {
    $submitted = trim($_POST['flag']);
    if ($submitted === $correct_flag) {
        $result = "<p style='color:green;'>✅ Correct! Flag accepted.</p>";
    } else {
        $result = "<p style='color:red;'>❌ Incorrect flag. Try again.</p>";
    }
}

// --------------------- VULNERABLE LFI ---------------------
if (isset($_GET['page'])) {
    $page = $_GET['page'];
    include($page); // No sanitization = LFI
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>PATH FINDER</title>
    <style>
        body { background-color: #f4f4f4; font-family: sans-serif; color: #333; }
        .container { width: 350px; margin: 50px auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.3);}
        input { width: 95%; padding: 10px; margin: 8px 0; border-radius: 4px; border: 1px solid #ccc; }
        input[type=submit] { background: #333; color: white; cursor: pointer; }
        .hint-box { margin-top: 20px; padding: 10px; background: #fffae6; border-left: 4px solid #ffc107; font-size: 0.9em; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Login Portal</h2>
        <form method="post">
            <input type="text" name="username" placeholder="Username" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <input type="submit" value="Login">
        </form>
        <p style='color:red;'> </p>

        <hr>

        <h2>🏁 Submit the Flag</h2>
        <form method="post">
            <input type="text" name="flag" placeholder="Enter your flag" name="flag" required>
            <input type="submit" value="Submit">
        </form>
        <?= $result ?>

        <div class="hint-box">
            💡 <strong>Hint:</strong> What if the login form is not the real target? Explore the paths... Sometimes the answer lies outside the Secret directory.
        </div>
    </div>
</body>
</html>

